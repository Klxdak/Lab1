func arithmetic(of a: Int, and b: Int) -> (sum: Int, difference: Int, product: Int, quotient: Int?) {
    let quotient: Int? = b == 0 ? nil : a / b
    return (sum: a + b, difference: a - b, product: a * b, quotient: quotient)
}
