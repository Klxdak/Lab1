enum TimeUnit {
    static let secondsPerMinute = 60
    static let secondsPerHour = 60 * secondsPerMinute
    static let secondsPerDay = 24 * secondsPerHour
    static let secondsPerYear = 365 * secondsPerDay
}
func timeInSeconds(forAge age: Int) -> (hour: Int, day: Int, year: Int, life: Int) {
    let hour = TimeUnit.secondsPerHour
    let day = TimeUnit.secondsPerDay
    let year = TimeUnit.secondsPerYear
    let life = age * year

    return (hour: hour, day: day, year: year, life: life)
}
