// The Swift Programming Language
// https://docs.swift.org/swift-book

@main
struct lab1 {
    static func main() {
        print("Podaj pierwszą liczbę:")
        guard let a = Int(readLine() ?? "") else {
            print("To nie jest liczba całkowita.")
            return
        }

        print("Podaj drugą liczbę:")
        guard let b = Int(readLine() ?? "") else {
            print("To nie jest liczba całkowita.")
            return
        }

        let wynik = arithmetic(of: a, and: b)
        print("Suma: \(wynik.sum)")
        print("Różnica: \(wynik.difference)")
        print("Iloczyn: \(wynik.product)")

        if let iloraz = wynik.quotient {
            print("Iloraz: \(iloraz)")
        } else {
            print("Iloraz: nie można dzielić przez zero")
        }
        let rok = lightYear()
        print("Rok świetlny: światło leci \(rok.seconds) s i pokonuje \(rok.kilometers) km")
        
        print("Podaj swój wiek:")
        guard let wiek = Int(readLine() ?? ""), wiek >= 0 else {
            print("Niepoprawny wiek.")
            return
        }

        let czas = timeInSeconds(forAge: wiek)
        print("Godzina ma \(czas.hour) s")
        print("Doba ma \(czas.day) s")
        print("Rok ma \(czas.year) s")
        print("Twoje życie trwa \(czas.life) s")
        print("Podaj liczbę cali:")
        guard let cale = Double(readLine() ?? "") else {
            print("To nie jest liczba.")
            return
        }
        print("\(cale) cali to \(centimeters(fromInches: cale)) cm")
        let jazda = speedSummary(first: (km: 30, minutes: 15), second: (km: 30, minutes: 12))
        print("Pierwszy odcinek: \(jazda.firstKmPerHour) km/h")
        print("Drugi odcinek: \(jazda.secondKmPerHour) km/h")
        print("Różnica: \(jazda.difference) km/h")
        print("Średnia z całej trasy: \(jazda.averageKmPerHour) km/h")
    }
}
