typealias Segment = (km: Double, minutes: Double)

func speedSummary(first: Segment, second: Segment)
    -> (firstKmPerHour: Double, secondKmPerHour: Double, difference: Double, averageKmPerHour: Double) {

    let firstKmPerHour = first.km / (first.minutes / 60)
    let secondKmPerHour = second.km / (second.minutes / 60)
    let difference = secondKmPerHour - firstKmPerHour

    let totalKm = first.km + second.km
    let totalHours = (first.minutes + second.minutes) / 60
    let averageKmPerHour = totalKm / totalHours

    return (firstKmPerHour: firstKmPerHour,
            secondKmPerHour: secondKmPerHour,
            difference: difference,
            averageKmPerHour: averageKmPerHour)
}
