func centimeters(fromInches inches: Double) -> Double {
    let centimetersPerInch = 2.54
    return inches * centimetersPerInch
}
