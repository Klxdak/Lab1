enum Physics {
    static let speedOfLightKmPerSecond = 299_792.458
}

func lightYear() -> (seconds: Int, kilometers: Double) {
    let seconds = TimeUnit.secondsPerYear
    let kilometers = Physics.speedOfLightKmPerSecond * Double(seconds)
    return (seconds: seconds, kilometers: kilometers)
}
